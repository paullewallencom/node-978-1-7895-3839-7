class Command {
  execute() {}
  undo() {}
}

module.exports = Command;
