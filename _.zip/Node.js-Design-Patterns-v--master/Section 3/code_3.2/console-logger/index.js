const write = log => console.log(`${new Date()} : ${log}`);

module.exports = {
  write
}